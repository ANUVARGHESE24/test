{
    'name': "Accounting Menus",
    'summary': """febno Custom""",
    'description': """
        Accounting Menus
            """,
    'author': "Athira",
    'website': "http://www.febno.com",
    'category': 'Test',
    'version': '0.1',
    'depends': ['base', 'sale', 'account'],
    'data': [
        'data/data.xml',
        'views/account_menu.xml',
        'views/res_config_settings_account_view.xml',
        # 'views/account_move_view.xml',

    ],

}
