## Module <account_partner_ledger_filter>

#### 01.05.2020
#### Version 13.0.1.0
#### ADD
Initial Commit for account_partner_ledger_filter
