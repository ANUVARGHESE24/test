{
    'name': "Warehouses and Operating Units",
    'summary': """Warehouses and Operating Units""",
    'description': """
       - Listing The Warehouses according to the selected Operating Unit
            """,
    'author': "Athira",
    'website': "http://www.febno.com",
    'category': 'Test',
    'version': '0.1',
    'depends': ['base', 'stock', 'sale', 'purchase', 'sale_stock'],
    'data': [

    ],

}
