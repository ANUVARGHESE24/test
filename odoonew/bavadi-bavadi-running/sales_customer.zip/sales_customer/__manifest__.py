{
    'name': "Sales Customer",
    'summary': """febno Custom""",
    'description': """
        Sales Customer
            """,
    'author': "Athira",
    'website': "http://www.febno.com",
    'category': 'Test',
    'version': '0.1',
    'depends': ['base', 'sale', 'account'],
    'data': [
        'data/customer_group.xml',
        'views/customer_menu.xml',
        'views/res_config_settings_view.xml',
        'views/account_move_view.xml',

    ],

}
