# -*- coding: utf-8 -*-
{
    'name': "Delivery in Accounting-updations",

    'summary': """Updations in Delivery in Accounting""",

    'description': """
    - button to get an Invoice number
     """,
    'author': "Rasha Rasheed",
    'website': "",
    'category': 'Test',
    'version': '0.1',

    'depends': ['base', 'account_delivery'],

    'data': [
        'views/button.xml',
    ],
}
