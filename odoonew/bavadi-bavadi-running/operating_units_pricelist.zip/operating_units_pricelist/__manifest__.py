{
    'name': "Operating Units Price list",
    'summary': """febno Custom""",
    'description': """
        Operation units Price list
            """,
    'author': "Athira",
    'website': "http://www.febno.com",
    'category': 'Test',
    'version': '0.1',
    'depends': ['base', 'sale', 'account', 'product'],
    'data': [
        'views/product_pricelist.xml'

    ],

}
