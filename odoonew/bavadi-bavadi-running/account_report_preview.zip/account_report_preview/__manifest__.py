# -*- coding: utf-8 -*-
{
    'name': "Report Preview for Accounting",

    'summary': """Report Preview for Accounting module""",

    'description': """ 
    - Preview commercial invoice report in Accounting module
    """,
    'author': "Rasha Rasheed",
    'website': "",
    'category': 'Test',
    'version': '0.1',

    'depends': ['base', 'account', 'account_com_report1'],

    'data': [
       
    ],
}
