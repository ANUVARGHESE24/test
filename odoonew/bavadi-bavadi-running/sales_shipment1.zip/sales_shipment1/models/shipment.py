from odoo import models, fields, api

class Shipment(models.Model):
    _inherit = "sale.order"

    total_qty = fields.Float(string="Total Quantity", compute='_total_qty', store=True)
    untaxed = fields.Float(string="Total Price", compute='_total_qty', store=True)
    invoice_no = fields.Char(string="Invoice No.", compute='_inv')
    dest = fields.Char(string="Destination", compute='_destination')

    @api.depends('order_line.product_uom_qty')
    def _total_qty(self):
        for order in self:
            total_qty = 0
            total_price = 0
            for line in order.order_line:
                if line.name != 'Ship Delivery Charges':
                    if line.name != 'Transport Delivery Charges':
                        total_qty += line.product_uom_qty
                        total_price += line.price_total
                order.total_qty = total_qty
                order.untaxed = total_price


    @api.depends('partner_id')
    def _destination(self):
        for order in self:
            if order.partner_id:
                partner = order.partner_id
                dest = partner.city
                dest1 = partner.country_id.name
                order.dest = str(dest) + "," + str(dest1)


    def _inv(self):
        for order in self:
            if order.invoice_ids:
                for i in order.invoice_ids:
                    if i.state != 'cancel':
                        order.invoice_no = i.name
            else:
                order.invoice_no = 'Null'
