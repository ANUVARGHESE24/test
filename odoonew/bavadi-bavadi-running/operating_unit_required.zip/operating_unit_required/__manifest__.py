{
    'name': "Required Operating Unit Field",
    'summary': """Required Operating Unit Field""",
    'description': """
        -Making The Operating Unit Field Required In Invoice Form
            """,
    'author': "Athira",
    'website': "http://www.febno.com",
    'category': 'Test',
    'version': '0.1',
    'depends': ['base', 'account', 'operating_unit', 'account_operating_unit'],
    'data': [

    ],

}
