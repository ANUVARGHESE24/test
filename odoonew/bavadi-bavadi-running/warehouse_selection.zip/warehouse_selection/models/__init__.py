from .import res_config_settings_inventory
from .import res_company
