# -*- coding: utf-8 -*-
from . import bank_statement_wiz
