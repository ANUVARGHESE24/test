# -*- coding: utf-8 -*-
{
    'name': "Purchase-Vendor",

    'summary': """Vendor menu in Purchase""",

    'description': """ """,
    'author': "Rasha Rasheed",
    'website': "",
    'category': 'Test',
    'version': '0.1',

    'depends': ['base', 'account', 'purchase'],

    'data': [
        'data/data.xml',
        'data/groups.xml',
        'views/vendor.xml',
    ],
}
