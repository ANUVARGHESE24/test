This module extends the Sales capabilities of Odoo and introduces the operating
unit to the Sales Order. Security rules are defined to ensure that users can
only display the Sales Orders in which they are allowed access to.
