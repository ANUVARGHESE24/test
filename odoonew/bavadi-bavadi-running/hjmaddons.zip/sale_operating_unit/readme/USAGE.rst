Follow these steps:

#. Create a Sale Order.
#. The Operating Unit of the Sale Team is assigned to the Sale Order.
